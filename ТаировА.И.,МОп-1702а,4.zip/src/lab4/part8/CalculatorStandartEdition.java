package lab4.part8;

public class CalculatorStandartEdition {

    public double calculateF1(double x) {
        return Math.cos(x);
    }

    public double calculateF2(double x) {
        return Math.pow(x, 1.0d / 3.0d);
    }
}
